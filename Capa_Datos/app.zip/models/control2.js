module.exports=ApPosInfo=class{


    //constructor(){}

    constructor( 
        mac,
        name,
        lat,
        long,
        xval,
        yval
        
        ){
        
        
        this.mac=mac;
        this.name=name;
        this.lat=lat;
        this.long=long;
        this.xval=xval;
        this.yval=yval;

    }
}